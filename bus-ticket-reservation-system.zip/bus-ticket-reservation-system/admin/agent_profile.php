<?php		 
  if(Session::get('admin_login')){
    $id = Session::get('id');
    $admin_by_id = $admin_info->GetAdminById($id);
    $data = $admin_by_id->fetch_assoc();


    /*session updating*/
    Session::set("name",$data['name']);
    Session::set("email",$data['email']);
    Session::set("img_url",$data['img_url']);

  } else if(Session::get('agent_login')) {
    $id = Session::get('id');
    $agent_by_id = $agent_info->GetAgentById($id);
    $data = $agent_by_id->fetch_assoc();

      /*session updating*/
        Session::set("name",$data['name']);
        Session::set("email",$data['email']);
        Session::set("img_url",$data['img_url']);
  }

   
?>	

<!----------Page content Stats--------------->

    <section class="content-header">
      <h1><strong>Profile Information</strong></h1>
      
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"></h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                    title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
		<?php if(isset($sms)){echo $sms;} ?>
        <div class="box-body">
		<div class="container">
      <div class="row">

        <div class="col-xs-8 col-xs-offset-2" >
   
   
          <div class="panel panel-info">
            <div class="panel-heading">
              <h3 class="panel-title"><strong><?php echo $data['name'];?></strong></h3>
            </div>
            <div class="panel-body">
              <div class="row">
                <div class="col-md-3 col-lg-3 " style="align: center"> <img alt="User Pic" src="<?php echo $data['img_url']; ?>" class="img-circle img-responsive"> </div>

                <div class=" col-md-9 col-lg-9 "> 
                  <table class="table table-user-information">
                    <tbody>
                        <tr>
                        <td>Permanent Address</td>
                        <td><?php echo $data['address']; ?></td>
                      </tr>
                      <tr>
                        <td>Email</td>
                        <td><a href=""><?php echo $data['email']; ?></a></td>
                      </tr>
                        <td>Phone Number</td>
                        <td><?php echo $data['phone_number']; ?><br><br>
                        </td>
                           
                      </tr>
                     
                    </tbody>
                  </table>
                  
                  <a href="#" class="btn btn-primary">My Sales Performance</a>
                  <a href="#" class="btn btn-primary">Team Sales Performance</a>
                </div>
              </div>
            </div>
                 <div class="panel-footer">
                        <a data-original-title="Broadcast Message" data-toggle="tooltip" type="button" class="btn btn-sm btn-primary"><i class="glyphicon glyphicon-envelope"></i></a>
                        <span class="pull-right">
                            <a href="edit.html" data-original-title="Edit this user" data-toggle="tooltip" type="button" class="btn btn-sm btn-warning"><i class="glyphicon glyphicon-edit"></i></a>
                            <a data-original-title="Remove this user" data-toggle="tooltip" type="button" class="btn btn-sm btn-danger"><i class="glyphicon glyphicon-remove"></i></a>
                        </span>
                    </div>
            
          </div>
        </div>
      </div>
    </div>
        </div>


 
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
