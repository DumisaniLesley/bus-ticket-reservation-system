<?php 
	require_once "../libs/Session.php";
  	Session::init();
  	Session::destroy();
  	
 ?>
<


  
 
 