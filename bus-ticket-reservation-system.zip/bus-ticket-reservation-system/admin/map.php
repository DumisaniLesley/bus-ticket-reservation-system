<style>
  /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
  #map {
    height: 80%;
  }

  /* Optional: Makes the sample page fill the window. */
  html,
  body {
    height: 100%;
    margin: 0;
    padding: 0;
  }

  #floating-panel {
    top: 10px;
    left: 25%;
    z-index: 5;
    background-color: #fff;
    padding: 5px;
    border: 1px solid #999;
    text-align: center;
    font-family: "Roboto", "sans-serif";
    line-height: 30px;
    padding-left: 10px;
}

select {
  width: 150px;
  padding: 5px;
  margin-right: 10px;
}

.Text-center {
  text-align: center;
}

.content-header {
  margin: 20px;
}
</style>
<script type="text/javascript">
    function initMap() {
      const directionsService = new google.maps.DirectionsService();
      const directionsRenderer = new google.maps.DirectionsRenderer();
      const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 7,
        center: { lat: 41.85, lng: -87.65 }
      });
      directionsRenderer.setMap(map);

      const onChangeHandler = function() {
        calculateAndDisplayRoute(directionsService, directionsRenderer);
      };
      document.getElementById("start").addEventListener("change", onChangeHandler);
      document.getElementById("end").addEventListener("change", onChangeHandler);
    }

    function calculateAndDisplayRoute(directionsService, directionsRenderer) {
      directionsService.route(
        {
          origin: {
            query: document.getElementById("start").value
          },
          destination: {
            query: document.getElementById("end").value
          },
          travelMode: google.maps.TravelMode.DRIVING
        },
        (response, status) => {
          if (status === "OK") {
            directionsRenderer.setDirections(response);
          } else {
            window.alert("Directions request failed due to " + status);
          }
        }
      );
    }
</script>
		
    <div class="content-header">
      <h1 class="Text-center">Bus Routes Map</h1>
	  
    </div>

    <!-- Main content -->
    <section class="content">
    <div id="floating-panel">
      <b>From: </b>
      <select id="start">
        <option value="lusaka, lsk">Lusaka</option>
        <option value="ndola, ndl">Ndola</option>
        <option value="joplin, mo">Joplin, MO</option>
        <option value="oklahoma city, ok">Oklahoma City</option>
        <option value="amarillo, tx">Amarillo</option>
        <option value="gallup, nm">Gallup, NM</option>
        <option value="flagstaff, az">Flagstaff, AZ</option>
        <option value="winona, az">Winona</option>
        <option value="kingman, az">Kingman</option>
        <option value="barstow, ca">Barstow</option>
        <option value="san bernardino, ca">San Bernardino</option>
        <option value="los angeles, ca">Los Angeles</option>
      </select>
      <b>To: </b>
      <select id="end">
      <option value="lusaka, lsk">Lusaka</option>
        <option value="ndola, ndl">Ndola</option>
        <option value="joplin, mo">Joplin, MO</option>
        <option value="oklahoma city, ok">Oklahoma City</option>
        <option value="amarillo, tx">Amarillo</option>
        <option value="gallup, nm">Gallup, NM</option>
        <option value="flagstaff, az">Flagstaff, AZ</option>
        <option value="winona, az">Winona</option>
        <option value="kingman, az">Kingman</option>
        <option value="barstow, ca">Barstow</option>
        <option value="san bernardino, ca">San Bernardino</option>
        <option value="los angeles, ca">Los Angeles</option>
      </select>
    </div>
    <div id="map"></div>

    </section>
    <!-- /.content -->
  </div>
  <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDcHZC1Zv1ZErqxikkF8JnUABvG6t4nm94&&region=ES&callback=initMap&libraries=&v=weekly"defer></script>