<?php
$id = $_GET['id'];
$trip_by_id = $trip_info->GetAllTripAndBusByTripId($id);
$data = $trip_by_id->fetch_assoc();

$AllCity = $city->GetAllCityByUniqueName();
$valueCity = mysqli_fetch_all($AllCity,MYSQLI_ASSOC);

$AllBus = $bus_info->GetAllBus();
$valueBus = mysqli_fetch_all($AllBus,MYSQLI_ASSOC);

if (isset($_POST['btn'])) {
    $update_trip = $trip_info->UpdateTripById($_POST,$id);
    $sms = '<div class="alert alert-success alert-dismissable"><a ref="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>'.$update_trip.'</strong> </div>';
         //header('location:index.php');
  }
?>

<!----------Page content Stats--------------->

    <section class="content-header">
      <h1>Add Route Information</h1>
      
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Route Information Form</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                    title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
		<?php if(isset($sms)){echo $sms;} ?>
        <div class="box-body">
		<div class="col-md-8 col-md-offset-2">
		     <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Update Route Information </h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post" enctype="multipart/form-data">
			
                <div class="box-body">

				
				<div class="form-group">
                  <label>Select a Bus:</label>
                  <select required class="form-control" name="bus_id">
                   <option value="">Select Bus</option>
					<?php 
					foreach($valueBus as $vBus)
					  {
					?>                        
                     <option <?php if($vBus['bus_id']==$data['bus_id']) echo 'selected'; ?> value="<?php echo $vBus['bus_id']; ?>"><?php echo $vBus['bus_no']; ?></option>  

                    <?php
					  }
					?>	
                          
                  </select>
                </div>
				
				
                <div class="form-group">
                  <label>From City:</label>
                  <select required class="form-control" name="from_city">
                    <option value="">Select from city</option>
					<?php 
					foreach($valueCity as $vCity)
					  {
					?>                        
                    <option <?php if($vCity['city_name']==$data['from_city']) echo 'selected'; ?> value="<?php echo $vCity['city_name']; ?>"><?php echo $vCity['city_name']; ?></option> 

                    <?php
					  }
					?>	
                          
                  </select>
                </div>
				
                <div class="form-group">
                  <label>To City:</label>
                  <select required class="form-control" name="to_city">
                    <option value="">Select to city</option>
					<?php 
					foreach($valueCity as $vCity)
					  {
					?>                        
               <option <?php if($vCity['city_name']==$data['to_city']) echo 'selected'; ?> value="<?php echo $vCity['city_name']; ?>"><?php echo $vCity['city_name']; ?></option> 

              <?php
					  }
					?>	
                          
                  </select>
                </div>
				
				<div class="form-group">
                  <label for="">Fare:</label>
                  <input required type="text" class="form-control"  name="fare" id="" value="<?php echo $data['fare']; ?>">
                </div>

             
			    <div class="form-group">
                  <label for="">Departure Time:</label>
                  <input required type="time" class="form-control"  name="dept_time" id="" value="<?php echo $data['departure_time']; ?>">
                </div>
				
				 <div class="form-group">
                  <label for="">Arriaval Time:</label>
                  <input required type="time" class="form-control" name="arrival_time" id="" value="<?php echo $data['arrival_time']; ?>" >
                </div>
							     
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" name="btn" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
          
        </div>
        </div>


 
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
