-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 04, 2020 at 06:06 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bus_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_info`
--

CREATE TABLE `tbl_admin_info` (
  `admin_id` int(11) NOT NULL,
  `name` char(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL,
  `img_url` varchar(40) NOT NULL,
  `activation_status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin_info`
--

INSERT INTO `tbl_admin_info` (`admin_id`, `name`, `email`, `phone_number`, `address`, `password`, `img_url`, `activation_status`) VALUES
(33, 'Dumisani Zulu', 'test@gmail.com', '0969704026', '3307 new mushili', '098f6bcd4621d373cade4e832627b4f6', 'agent_img/b4e745445c.png', 1),
(34, 'Xulu', 'xulu@gmail.com', '0955100100', '1200 new street', '81dc9bdb52d04dc20036dbd8313ed055', 'agent_img/c914b68567.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_agent_info`
--

CREATE TABLE `tbl_agent_info` (
  `agent_id` int(11) NOT NULL,
  `counter_id` int(11) NOT NULL,
  `name` char(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(33) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(100) NOT NULL,
  `img_url` varchar(40) NOT NULL,
  `active_status` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_agent_info`
--

INSERT INTO `tbl_agent_info` (`agent_id`, `counter_id`, `name`, `email`, `phone_number`, `address`, `password`, `img_url`, `active_status`) VALUES
(1, 9, 'Dumisani', 'lusaka@gmail.com', '0978646664', 'plot 102, Lusaka', '098f6bcd4621d373cade4e832627b4f6', 'agent_img/3823f34113.png', 1),
(2, 10, 'Ndola Agent', 'ndola@gmail.com', '0966100100', 'plot 1, Ndola', '2e99bf4e42962410038bc6fa4ce40d97', 'agent_img/3bcd2eb01c.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_booked_seats`
--

CREATE TABLE `tbl_booked_seats` (
  `id` int(11) NOT NULL,
  `pnr_no` int(40) NOT NULL,
  `trip_id` int(40) NOT NULL,
  `passenger_id` int(11) NOT NULL,
  `seat_no` varchar(5) NOT NULL,
  `date` date NOT NULL,
  `seat_status` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_booked_seats`
--

INSERT INTO `tbl_booked_seats` (`id`, `pnr_no`, `trip_id`, `passenger_id`, `seat_no`, `date`, `seat_status`) VALUES
(98, 24565, 6, 4, 'A1', '2018-04-10', 0),
(99, 24565, 6, 4, 'A2', '2018-04-10', 0),
(100, 14729, 6, 4, 'B2', '2018-04-10', 0),
(103, 28046, 6, 4, 'D3', '2018-04-10', 1),
(105, 27611, 5, 4, 'A2', '2018-04-10', 1),
(106, 27611, 5, 4, 'A1', '2018-04-10', 1),
(107, 15227, 5, 4, 'C4', '2018-04-06', 1),
(108, 15227, 5, 4, 'C3', '2018-04-06', 1),
(109, 8016, 5, 6, 'A1', '2018-04-07', 1),
(110, 8016, 5, 6, 'A2', '2018-04-07', 1),
(111, 8016, 5, 6, 'B1', '2018-04-07', 1),
(112, 8016, 5, 6, 'B2', '2018-04-07', 1),
(113, 2042, 13, 7, 'A2', '0000-00-00', 1),
(114, 2617, 13, 7, 'A1', '2020-09-24', 1),
(115, 5100, 1, 7, 'D1', '0000-00-00', 1),
(116, 5100, 1, 7, 'E1', '0000-00-00', 1),
(117, 5100, 1, 7, 'E2', '0000-00-00', 1),
(118, 5100, 1, 7, 'D2', '0000-00-00', 1),
(119, 2895, 1, 7, 'A1', '2020-09-26', 1),
(120, 9988, 1, 7, 'C3', '2020-09-24', 0),
(121, 9988, 1, 7, 'C4', '2020-09-24', 0),
(122, 9988, 1, 7, 'D3', '2020-09-24', 0),
(123, 9988, 1, 7, 'D4', '2020-09-24', 0),
(124, 6627, 5, 7, 'A1', '2020-09-25', 1),
(125, 6627, 5, 7, 'B1', '2020-09-25', 1),
(126, 6627, 5, 7, 'A2', '2020-09-25', 1),
(127, 6627, 5, 7, 'B2', '2020-09-25', 1),
(128, 2305, 4, 7, 'A1', '2020-09-25', 1),
(129, 6018, 2, 7, 'A1', '2020-09-26', 1),
(131, 1982, 6, 8, 'J2', '2020-09-27', 1),
(132, 7150, 9, 8, 'A1', '2020-09-27', 1),
(133, 7150, 9, 8, 'A2', '2020-09-27', 1),
(134, 7150, 9, 8, 'B1', '2020-09-27', 1),
(135, 7150, 9, 8, 'B2', '2020-09-27', 1),
(136, 6710, 1, 8, 'A1', '2020-09-30', 1),
(137, 6710, 1, 8, 'A2', '2020-09-30', 1),
(138, 6710, 1, 8, 'A3', '2020-09-30', 1),
(139, 6710, 1, 8, 'A4', '2020-09-30', 1),
(140, 6529, 5, 9, 'C1', '2020-09-29', 1),
(141, 6529, 5, 9, 'D3', '2020-09-29', 1),
(142, 6529, 5, 9, 'H1', '2020-09-29', 1),
(143, 6529, 5, 9, 'A2', '2020-09-29', 1),
(144, 1843, 1, 9, 'B1', '2020-09-30', 1),
(145, 1843, 1, 9, 'B2', '2020-09-30', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_booking_info`
--

CREATE TABLE `tbl_booking_info` (
  `booking_id` int(40) NOT NULL,
  `pnr_no` int(40) NOT NULL,
  `trip_id` int(40) NOT NULL,
  `counter_id` int(40) NOT NULL,
  `passenger_id` int(11) NOT NULL,
  `reference_no` varchar(60) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `journey_date` date NOT NULL,
  `booking_date` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `booking_status` int(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_booking_info`
--

INSERT INTO `tbl_booking_info` (`booking_id`, `pnr_no`, `trip_id`, `counter_id`, `passenger_id`, `reference_no`, `total_amount`, `journey_date`, `booking_date`, `booking_status`) VALUES
(16, 28046, 6, 2, 4, 'dfst353', 560, '2018-04-10', '2018-04-05 20:05:53', 1),
(18, 27611, 5, 2, 4, 'swfre d', 3000, '2018-04-10', '2018-04-05 20:33:32', 1),
(19, 15227, 5, 2, 4, 'vdfe34', 3000, '2018-04-06', '2018-04-07 02:40:37', 1),
(20, 8016, 5, 2, 6, '4777', 6000, '2018-04-07', '2018-04-07 16:29:28', 1),
(21, 2042, 13, 8, 7, '12345', 200, '0000-00-00', '2020-09-22 15:39:40', 1),
(22, 2617, 13, 8, 7, '12345', 200, '2020-09-24', '2020-09-22 15:39:17', 1),
(23, 5100, 1, 9, 7, '2020', 680, '0000-00-00', '2020-09-22 17:30:57', 1),
(24, 2895, 1, 9, 7, '1000', 170, '2020-09-26', '2020-09-22 18:47:24', 1),
(25, 9988, 1, 9, 7, '11111', 680, '2020-09-24', '2020-09-22 19:11:44', 2),
(26, 6627, 5, 10, 7, '2452', 800, '2020-09-25', '2020-09-23 14:34:30', 1),
(27, 2305, 4, 9, 7, '2121', 170, '2020-09-25', '2020-09-23 14:44:49', 1),
(28, 6018, 2, 9, 7, '2323', 200, '2020-09-26', '2020-09-23 14:52:02', 1),
(30, 1982, 6, 12, 8, '7890', 400, '2020-09-27', '2020-09-26 07:07:46', 1),
(31, 7150, 9, 14, 8, '45678', 200, '2020-09-27', '2020-09-26 07:20:22', 1),
(32, 6710, 1, 9, 8, 'qw1234', 680, '2020-09-30', '2020-09-28 07:44:39', 1),
(33, 6529, 5, 10, 9, '11111', 800, '2020-09-29', '2020-09-29 06:30:19', 1),
(34, 1843, 1, 9, 9, '472829', 340, '2020-09-30', '2020-09-29 06:33:33', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bus_info`
--

CREATE TABLE `tbl_bus_info` (
  `bus_id` int(11) NOT NULL,
  `bus_no` varchar(11) NOT NULL,
  `bus_type` char(20) NOT NULL,
  `img_bus` varchar(40) NOT NULL,
  `no_of_seats` int(11) NOT NULL DEFAULT 40
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_bus_info`
--

INSERT INTO `tbl_bus_info` (`bus_id`, `bus_no`, `bus_type`, `img_bus`, `no_of_seats`) VALUES
(1, 'BAE 314', 'Luxury Coach', 'img/112d3fca22.jpg', 40),
(2, 'BAE 2134', 'A/C Sleeper', 'img/b447f7f5af.jpg', 40),
(3, 'BAC 2002', 'Stream Line', 'img/7f3baf71a8.jpg', 40),
(4, 'BCC 1212', 'Luxury Coach', 'img/b38895355e.jpg', 40),
(5, 'EAC 2020', 'Luxury Coach', 'img/2f315d6291.jpg', 40),
(6, 'DEA', 'Stream Line', 'img/da41a30bc3.jpg', 40);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cancel_request`
--

CREATE TABLE `tbl_cancel_request` (
  `request_id` int(11) NOT NULL,
  `pnr_no` int(40) NOT NULL,
  `counter_id` int(40) NOT NULL,
  `bkash_no` varchar(15) NOT NULL,
  `cancel_status` int(15) NOT NULL DEFAULT 0,
  `cancel_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_cancel_request`
--

INSERT INTO `tbl_cancel_request` (`request_id`, `pnr_no`, `counter_id`, `bkash_no`, `cancel_status`, `cancel_date`) VALUES
(7, 28046, 2, '01738868597', 0, '2018-04-06 21:03:43'),
(8, 9988, 9, '0978646664', 0, '2020-09-22 19:11:11');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cities`
--

CREATE TABLE `tbl_cities` (
  `city_id` int(40) NOT NULL,
  `city_name` char(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_cities`
--

INSERT INTO `tbl_cities` (`city_id`, `city_name`) VALUES
(1, 'Lusaka'),
(2, 'Ndola'),
(3, 'Kabwe'),
(4, 'Livingstone'),
(5, 'Kitwe'),
(6, 'Nakonde'),
(7, 'Kapiri Mposhi'),
(8, 'Choma'),
(9, 'Kafue'),
(10, 'Mazabuka'),
(11, 'Mkushi'),
(12, 'Chipata'),
(13, 'Mansa'),
(14, 'Kasama'),
(15, 'Solwezi');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_complain`
--

CREATE TABLE `tbl_complain` (
  `com_id` int(40) NOT NULL,
  `com_nam` char(40) NOT NULL,
  `com_email` varchar(60) NOT NULL,
  `subject` char(100) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_complain`
--

INSERT INTO `tbl_complain` (`com_id`, `com_nam`, `com_email`, `subject`, `description`) VALUES
(1, 'akram chowdhuri', 'akram@gmail.com', 'Booking Issues', 'In Ena transport I did not get booking after payment'),
(2, 'mahmud mahadi', 'mahadi@gmail.com', 'Booking Issues', 'did not get booking after payment');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_counter_info`
--

CREATE TABLE `tbl_counter_info` (
  `counter_id` int(40) NOT NULL,
  `city_name` char(40) NOT NULL,
  `counter_name` char(50) NOT NULL,
  `contact_no` varchar(15) NOT NULL,
  `location_counter` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_counter_info`
--

INSERT INTO `tbl_counter_info` (`counter_id`, `city_name`, `counter_name`, `contact_no`, `location_counter`) VALUES
(9, 'Lusaka', 'InterCity Bus Terminus', '0978646664', 'Lusaka'),
(10, 'Ndola', 'BroadWay Bus Terminal', '0969704026', 'Ndola'),
(11, 'Livingstone', 'Town Center', '0978646664', 'Livingstone'),
(12, 'Chipata', 'Chipata Town Center', '0955 555 555', 'Chipata, Chipata'),
(13, 'Nakonde', 'Town Center, Nakonde', '0955 555 555', 'Nakonde'),
(14, 'Kitwe', 'Chisokone Bus Station', '0969704026', 'Kitwe');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_passenger_info`
--

CREATE TABLE `tbl_passenger_info` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_passenger_info`
--

INSERT INTO `tbl_passenger_info` (`id`, `name`, `address`, `email`, `mobile`, `password`) VALUES
(1, 'Abdullah', 'Uttara', 'abdullah001rti@gmail.com', '01738868597', '25199d992c5541ac329277c20205ba18'),
(5, 'MD. Abdullah', 'Bamnartek, Uttara, Dhaka-1230', 'abd1@gmail.com', '01738868597', '41a60377ba920919939d83326ebee5a1'),
(4, 'Abdullah', 'Uttara', 'abd@gmail.com', '01738868597', '41a60377ba920919939d83326ebee5a1'),
(6, 'SAAD', 'Uttara Dhaka', 'raselhasandurjoy@gmail.com', '01904654712', '202cb962ac59075b964b07152d234b70'),
(7, 'Dumisani Lesley', '3307 new mushili', 'test@gmail.com', '0978646664', '81dc9bdb52d04dc20036dbd8313ed055'),
(8, 'lesley', '200 new street', 'lesley@gmail.com', '0954035130', '81dc9bdb52d04dc20036dbd8313ed055'),
(9, 'Mutale Moyo', 'Ks 5174', 'mutaleben513@gmail.com', '0971206417', '827ccb0eea8a706c4c34a16891f84e7b');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reserved_seat`
--

CREATE TABLE `tbl_reserved_seat` (
  `id` int(11) NOT NULL,
  `trip_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `bus_id` int(11) NOT NULL,
  `booked_time` datetime NOT NULL DEFAULT current_timestamp(),
  `date` date NOT NULL,
  `seat_no` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_reserved_seat`
--

INSERT INTO `tbl_reserved_seat` (`id`, `trip_id`, `user_id`, `session_id`, `bus_id`, `booked_time`, `date`, `seat_no`) VALUES
(1359, 5, 5, 'dttc5l1m9d3j9ac4gih21nab82', 1, '2018-04-06 21:54:49', '2018-04-11', 'I2'),
(1379, 5, 4, 't41p4rul5da01a6ve4ab2dh760', 1, '2018-04-06 22:04:25', '2018-04-11', 'G2'),
(1369, 5, 5, 'dttc5l1m9d3j9ac4gih21nab82', 1, '2018-04-06 21:59:57', '2018-04-11', 'H2'),
(1373, 5, 4, 't41p4rul5da01a6ve4ab2dh760', 1, '2018-04-06 22:00:14', '2018-04-11', 'A2'),
(1380, 5, 5, 'dttc5l1m9d3j9ac4gih21nab82', 1, '2018-04-06 22:04:28', '2018-04-11', 'F2'),
(1381, 5, 5, 'dttc5l1m9d3j9ac4gih21nab82', 1, '2018-04-06 22:04:29', '2018-04-11', 'E2'),
(1382, 5, 6, '32j84gg8e16n214qstmi7v8uqu', 1, '2018-04-07 22:19:42', '2018-04-07', 'A1'),
(1383, 5, 6, '32j84gg8e16n214qstmi7v8uqu', 1, '2018-04-07 22:19:43', '2018-04-07', 'A2'),
(1384, 5, 6, '32j84gg8e16n214qstmi7v8uqu', 1, '2018-04-07 22:19:43', '2018-04-07', 'B1'),
(1385, 5, 6, '32j84gg8e16n214qstmi7v8uqu', 1, '2018-04-07 22:19:44', '2018-04-07', 'B2'),
(1395, 1, 7, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-22 19:25:30', '0000-00-00', 'D1'),
(1398, 1, 7, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-22 19:25:44', '0000-00-00', 'E1'),
(1399, 1, 7, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-22 19:25:45', '0000-00-00', 'E2'),
(1392, 13, 7, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-22 17:10:02', '2020-09-24', 'A1'),
(1406, 1, 7, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-23 16:30:51', '0000-00-00', 'D3'),
(1400, 1, 7, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-22 20:46:29', '2020-09-26', 'A1'),
(1402, 1, 7, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-22 20:58:08', '2020-09-24', 'C3'),
(1403, 1, 7, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-22 20:58:09', '2020-09-24', 'C4'),
(1404, 1, 7, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-22 20:58:10', '2020-09-24', 'D3'),
(1405, 1, 7, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-22 20:58:10', '2020-09-24', 'D4'),
(1407, 5, 7, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-23 16:33:21', '2020-09-25', 'A1'),
(1408, 5, 7, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-23 16:33:23', '2020-09-25', 'B1'),
(1409, 5, 7, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-23 16:33:26', '2020-09-25', 'A2'),
(1411, 5, 7, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-23 16:33:29', '2020-09-25', 'B2'),
(1412, 4, 7, 'd273kcsr223kqtbusf3bq7shss', 4, '2020-09-23 16:43:32', '2020-09-25', 'A1'),
(1413, 2, 7, 'd273kcsr223kqtbusf3bq7shss', 2, '2020-09-23 16:51:26', '2020-09-26', 'A1'),
(1414, 1, 8, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-25 09:27:30', '2020-09-26', 'B2'),
(1415, 3, 8, 'd273kcsr223kqtbusf3bq7shss', 3, '2020-09-25 20:36:58', '2020-09-26', 'B3'),
(1416, 3, 8, 'd273kcsr223kqtbusf3bq7shss', 3, '2020-09-25 21:05:02', '2020-09-26', 'G2'),
(1417, 3, 8, 'd273kcsr223kqtbusf3bq7shss', 3, '2020-09-25 21:05:02', '2020-09-26', 'G2'),
(1418, 6, 8, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-26 09:04:37', '2020-09-27', 'J2'),
(1419, 9, 8, 'd273kcsr223kqtbusf3bq7shss', 2, '2020-09-26 09:18:18', '2020-09-27', 'A1'),
(1420, 9, 8, 'd273kcsr223kqtbusf3bq7shss', 2, '2020-09-26 09:18:18', '2020-09-27', 'A2'),
(1424, 9, 8, 'd273kcsr223kqtbusf3bq7shss', 2, '2020-09-26 09:18:27', '2020-09-27', 'B1'),
(1422, 9, 8, 'd273kcsr223kqtbusf3bq7shss', 2, '2020-09-26 09:18:19', '2020-09-27', 'B2'),
(1425, 10, 8, 'd273kcsr223kqtbusf3bq7shss', 2, '2020-09-26 09:33:11', '2020-09-27', 'A1'),
(1426, 1, 8, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-28 09:43:22', '2020-09-30', 'A1'),
(1427, 1, 8, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-28 09:43:23', '2020-09-30', 'A2'),
(1428, 1, 8, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-28 09:43:24', '2020-09-30', 'A3'),
(1430, 1, 8, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-28 09:43:27', '2020-09-30', 'A4'),
(1431, 5, 9, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-29 08:28:05', '2020-09-29', 'C1'),
(1432, 5, 9, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-29 08:28:10', '2020-09-29', 'D3'),
(1433, 5, 9, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-29 08:28:12', '2020-09-29', 'H1'),
(1434, 5, 9, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-29 08:28:14', '2020-09-29', 'A2'),
(1435, 1, 9, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-29 08:32:52', '2020-09-30', 'B1'),
(1436, 1, 9, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-29 08:32:54', '2020-09-30', 'B2'),
(1437, 1, 9, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-29 08:34:30', '2020-09-30', 'F4'),
(1438, 1, 9, 'd273kcsr223kqtbusf3bq7shss', 1, '2020-09-29 08:34:30', '2020-09-30', 'F3'),
(1440, 9, 7, 'd273kcsr223kqtbusf3bq7shss', 2, '2020-09-29 08:44:34', '2020-09-29', 'H2');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_trip_info`
--

CREATE TABLE `tbl_trip_info` (
  `trip_id` int(11) NOT NULL,
  `bus_id` int(11) NOT NULL,
  `from_city` char(40) NOT NULL,
  `to_city` char(40) NOT NULL,
  `fare` varchar(40) NOT NULL,
  `departure_time` varchar(12) NOT NULL,
  `arrival_time` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_trip_info`
--

INSERT INTO `tbl_trip_info` (`trip_id`, `bus_id`, `from_city`, `to_city`, `fare`, `departure_time`, `arrival_time`) VALUES
(1, 1, 'Lusaka', 'Ndola', '170', '05:30', '12:30'),
(2, 2, 'Lusaka', 'Ndola', '200', '08:00', '14:00'),
(3, 3, 'Lusaka', 'Ndola', '170', '10:00', '16:00'),
(4, 4, 'Lusaka', 'Ndola', '170', '14:00', '20:00'),
(5, 1, 'Ndola', 'Lusaka', '200', '10:00', '16:00'),
(6, 1, 'Chipata', 'Livingstone', '400', '04:00', '17:00'),
(7, 3, 'Ndola', 'Solwezi', '250', '04:00', '12:30'),
(8, 3, 'Nakonde', 'Lusaka', '300', '04:00', '20:00'),
(9, 2, 'Kitwe', 'Ndola', '50', '06:00', '08:00'),
(10, 2, 'Ndola', 'Kitwe', '50', '08:30', '10:30'),
(11, 3, 'Kitwe', 'Solwezi', '200', '04:00', '12:30'),
(12, 6, 'Kasama', 'Ndola', '250', '08:52', '18:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin_info`
--
ALTER TABLE `tbl_admin_info`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbl_agent_info`
--
ALTER TABLE `tbl_agent_info`
  ADD PRIMARY KEY (`agent_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbl_booked_seats`
--
ALTER TABLE `tbl_booked_seats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_booking_info`
--
ALTER TABLE `tbl_booking_info`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `tbl_bus_info`
--
ALTER TABLE `tbl_bus_info`
  ADD PRIMARY KEY (`bus_id`);

--
-- Indexes for table `tbl_cancel_request`
--
ALTER TABLE `tbl_cancel_request`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `tbl_cities`
--
ALTER TABLE `tbl_cities`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `tbl_complain`
--
ALTER TABLE `tbl_complain`
  ADD PRIMARY KEY (`com_id`);

--
-- Indexes for table `tbl_counter_info`
--
ALTER TABLE `tbl_counter_info`
  ADD PRIMARY KEY (`counter_id`);

--
-- Indexes for table `tbl_passenger_info`
--
ALTER TABLE `tbl_passenger_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_reserved_seat`
--
ALTER TABLE `tbl_reserved_seat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_trip_info`
--
ALTER TABLE `tbl_trip_info`
  ADD PRIMARY KEY (`trip_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin_info`
--
ALTER TABLE `tbl_admin_info`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `tbl_agent_info`
--
ALTER TABLE `tbl_agent_info`
  MODIFY `agent_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_booked_seats`
--
ALTER TABLE `tbl_booked_seats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;

--
-- AUTO_INCREMENT for table `tbl_booking_info`
--
ALTER TABLE `tbl_booking_info`
  MODIFY `booking_id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `tbl_bus_info`
--
ALTER TABLE `tbl_bus_info`
  MODIFY `bus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_cancel_request`
--
ALTER TABLE `tbl_cancel_request`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_cities`
--
ALTER TABLE `tbl_cities`
  MODIFY `city_id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_complain`
--
ALTER TABLE `tbl_complain`
  MODIFY `com_id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_counter_info`
--
ALTER TABLE `tbl_counter_info`
  MODIFY `counter_id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_passenger_info`
--
ALTER TABLE `tbl_passenger_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_reserved_seat`
--
ALTER TABLE `tbl_reserved_seat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1442;

--
-- AUTO_INCREMENT for table `tbl_trip_info`
--
ALTER TABLE `tbl_trip_info`
  MODIFY `trip_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
